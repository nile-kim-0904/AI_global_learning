#!/usr/bin/env python
# coding: utf-8

# In[1]:


import test_module as test

radius = test.number_input()

print(test.get_circum(radius))
print(test.get_circle_area(radius))

