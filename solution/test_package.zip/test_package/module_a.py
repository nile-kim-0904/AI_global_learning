#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# ./test_package/module_a.py
variable_a = "a 모듈의 변수 "

