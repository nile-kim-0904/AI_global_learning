# from test_package import * 로 모듈을 읽고자 할 경우
__all__ = ["module_a", "module_b"]
print("init 실행 ")

