#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# ./test_package/module_b.py
variable_b = "b 모듈의 변수 "

